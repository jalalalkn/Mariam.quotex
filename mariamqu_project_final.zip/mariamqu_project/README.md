# mariamqu

Pastel Android screen analyzer for live chart reading.

## What is included
- MediaProjection screen capture
- Foreground capture service
- Frame bus with buffered streaming
- ROI calibration and chart-focused cropping
- Heuristic candle analysis
- Multi-strategy signal engine
- Self-learning weights based on win/loss feedback
- Persistent stats and recent signal history
- Pastel pink Compose UI

## How it works
1. Start capture and grant screen permission.
2. Place Quotex and mariamqu in split-screen.
3. Tune the crop sliders so the chart fills the sampled area.
4. The app scores each frame, builds a live signal, and logs performance.

## Notes
- This project reads the visible screen only.
- The signal engine produces probabilistic analysis, not certainty.
- For a production upgrade, replace the heuristic analyzer with OpenCV + TensorFlow Lite + optional OCR.

## Build on Codemagic
- Put the repository on GitHub as private if you want privacy.
- Keep `codemagic.yaml` in the repository root.
- Codemagic workflow builds `app/build/outputs/**/*.apk`.
